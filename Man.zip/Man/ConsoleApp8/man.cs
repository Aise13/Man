﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ManTest
{
    class ManUsingprogram
    {
        static void Main(string[] args)
        {
            string user_command = "";
            
            Man SomeMan = null;

            bool Infinity = true;

            while (Infinity)
            {
                System.Console.WriteLine("Пожалуйста, введите комнаду");
                System.Console.WriteLine("Для того, что узнать возможности программы, введите команду 'help' ");
                System.Console.WriteLine("Для выхода из программы введите Exit");
                user_command = Console.ReadLine();

                switch (user_command)
                {
                    case "exit":
                        {
                            Infinity = false;
                            break;
                        }
                    case "help":
                        {
                            System.Console.WriteLine("Список команд:");
                            System.Console.WriteLine("---");

                            System.Console.WriteLine("1: команада создаёт человека, (экземпляр класса Man)");
                            System.Console.WriteLine("2: комнада убивает человека");
                            System.Console.WriteLine("3: команда заставляет человека  говорить (если создан экземпляр класса)");
                            System.Console.WriteLine("4: команда заставляет человека идти (если создан экземпляр класса)");

                            System.Console.WriteLine("---");
                            System.Console.WriteLine("---");

                            break;

                        }
                    default:
                        {
                            System.Console.WriteLine("Ваша команда не определена, пожалуйста, повторите снова");
                            System.Console.WriteLine("Для вывода списка команд введите комнаду help");
                            System.Console.WriteLine("Для завершения программы введите команду exit");
                            break;
                        }
                    case "1":
                        {

                            if (SomeMan != null)
                            {
                                SomeMan.Kill();
                            }
                            System.Console.WriteLine("Пожалуйста, введите имя создаваемого человека");
                            user_command = System.Console.ReadLine();
                            SomeMan = new Man(user_command);
                            System.Console.WriteLine("Человек успешно создан");

                            break;
                        }
                    case "2":
                        {
                            if (SomeMan != null)
                            {
                                SomeMan.Kill();
                            }
                            break;
                        }
                    case "3":
                        {
                            if (SomeMan != null)
                            {
                                SomeMan.Talk();
                            }
                            else
                            {
                                System.Console.WriteLine("Человек не создан. Комнада не может быть выполнена");
                            }
               
                            break; 
                        }
                    case "4":
                        {
                            if (SomeMan != null)
                            {
                                SomeMan.Go();
                            }
                            else
                            {
                                System.Console.WriteLine("Человек не создан. Команда не может быть выполнена");
                            }
                            break;
                        }

                }
            }
        }
    }
    public class Man
    {
        private Random rnd = new Random();
        public bool isLife;
        public Man(string _name)
        {
            Name = _name;
            isLife = true;
            Age = (uint)rnd.Next(15, 51);
            Health = (uint)rnd.Next(10, 101);
        }
        private string Name;
        private uint Age;
        private uint Health;
        public void Talk()
        {
            int random_talk = rnd.Next(1, 4);
            string tmp_str = "";
            if (isLife == true)
            {
                switch (random_talk)
                {
                    case 1:
                        {
                            tmp_str = "Привет, меня зовут " + Name + ", рад познакомиться";
                            break;
                        }
                    case 2:
                        {
                            tmp_str = "Мне " + Age + ". А тебе?";
                            break;
                        }
                    case 3:
                        {
                            if (Health > 50)
                                tmp_str = "Да, я здоров!";
                            else
                                tmp_str = "" + (Age + 10).ToString();
                            break;
                        }
                }
            }
            else
            {
                System.Console.WriteLine("Трупы не умеют разговаривать");
            }    
            System.Console.WriteLine(tmp_str);
        }
        public void Go()
        {
            if (isLife == true)
            {
                if (Health > 40)
                {
                    string outString = Name + " мирно прогуливается по городу";
                    System.Console.WriteLine(outString);
                }
                else
                {
                    string outString = Name + " болен и не может гулять по городу";
                    System.Console.WriteLine(outString);
                }
            }
            else
            {
                string outString = Name + " не может идти, он умер";
                System.Console.WriteLine(outString);
            }
        }
        public bool IsAlive()
        {
            return isLife;
        }
        public void Kill()
        {
            isLife = false;
            Console.WriteLine("Человек убит");
        }
    } 
}
